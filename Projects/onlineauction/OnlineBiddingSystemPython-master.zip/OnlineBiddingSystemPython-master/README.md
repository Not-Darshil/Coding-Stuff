# OnlineBiddingSystemPython

### youtube video = <a href="https://youtu.be/7dj0B4hTrgQ">Link</a>

**you are supposed to write your email and app password in settings.py**<br/>

**At line 131,132**


```python

EMAIL_HOST_USER = 'YOUR EMAIL'
EMAIL_HOST_PASSWORD = "YOUR EMAIL'S APP-PASSWORD"

```

Refer this link for generating app password -> https://devanswers.co/create-application-specific-password-gmail
